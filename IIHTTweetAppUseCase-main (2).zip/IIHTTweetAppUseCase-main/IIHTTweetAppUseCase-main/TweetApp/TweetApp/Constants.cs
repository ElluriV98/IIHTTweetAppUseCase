﻿namespace TweetApp
{
    public class Constants
    {
        public const string RegisterSuccess = "Registration succesfully, Start your Tweet.";
        public const string LoginSuccess = "Logged in succcessfully, Check your Tweets.";
        public const string LoginFailure = "Invalid username or password, Please enter valid credentials.";
        public const string RegisterFailed = "Email id registereed,please try login";
        public const string EnterUserDetails = "Please enter the details";
        public const string InsertSuccess = "Posted new Tweet successfully.";
        public const string InsertFailed = "Failed,Repost the Tweet";
        public const string UpdateSuccess = "Password updated successfully";
        public const string UpdateFailed = "password updation failed, please enter valid credentails";
        public const string ModifyPass = "you can reset the password";
        public const string ModifyPassFail = "you cannot resset the password";
    }
}
