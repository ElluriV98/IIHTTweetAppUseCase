﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using TweetApp.Models;
using TweetApp.Services;

namespace TweetApp.Controllers
{
    /// <summary>
    /// TweetController.
    /// </summary>
    [Route("api/[controller]")]
    public class TweetController : Controller
    {
        private readonly ITweetService service;
        private readonly ILogger<TweetController> logger;

        /// <summary>
        /// Create the instance of the tweetController.
        /// </summary>
        /// <param name="service">service.</param>
        public TweetController(ITweetService service, ILogger<TweetController> logger)
        {
            this.service = service;
            this.logger = logger;
        }

        /// <summary>
        /// Adds the new tweet
        /// </summary>
        /// <param name="tweet">Tweet.</param>
        /// <returns>returns the status message.</returns>
        
        [Route("AddNewTweet")]
        [HttpPost]
        public IActionResult AddNewTweet(Tweets tweet )
        {
            string message = null;
            try
            {
                this.logger.LogTrace("Entered Try block of Add New Tweet");
                if (tweet != null)
                {
                    message = this.service.AddNewTweet(tweet);
                }

            }
            catch(Exception ex)
            {
                this.logger.LogError("Add New Tweet",ex);
            }
            return Ok(message);
        }

        /// <summary>
        /// Views all user tweets.
        /// </summary>
        /// <param name="userId">userId.</param>
        /// <returns>returns all the user tweets.</returns>
        [Route("ViewUserAllTweets")]
        [HttpGet]
        public List<Tweets> ViewUserAllTweets(string userId)
        {
            List<Tweets> tweets = new List<Tweets>();
            try
            {
                this.logger.LogTrace("Entered try block of View User All Tweets");
                if (!string.IsNullOrEmpty(userId))
                {
                    tweets = this.service.GetUserTweets(userId);                   
                }            
            }
            catch (Exception ex)
            {
                this.logger.LogError("View User All Tweets", ex);
            }
            return tweets;
        } 
        
        /// <summary>
        /// Get all the users list.
        /// </summary>
        /// <returns>returns all the users.</returns>
        [Route("GetAllUserList")]
        [HttpGet]
        public List<AllUsers> GetAllUserList()
        {
            List<AllUsers> userList = new List<AllUsers>();
            try
            {
                this.logger.LogTrace("Entered try block of Get All User List");
                userList =this.service.AllUserList();
            }
            catch (Exception ex)
            {
                this.logger.LogError("Get All User List", ex);
            }
            return userList;
        }

        [Route("GetAllUserandTweetList")]
        [HttpGet]
        public List<Tweets> GetAllUsersTweetList()
        {
            List<Tweets> userList = new List<Tweets>();
            try
            {
                this.logger.LogTrace("Entered try block of Gets All Users Tweet List");
                userList = this.service.GetUserandTweetList();
            }
            catch (Exception ex)
            {
                this.logger.LogError("Gets All Users Tweet List", ex);
            }
            return userList;
        }

    }
}
