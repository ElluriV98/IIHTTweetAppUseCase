﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using TweetApp.Models;
using TweetApp.Services;

namespace TweetApp.Controllers
{
    /// <summary>
    /// userController.
    /// </summary>
    [Route("api/[controller]")]
    public class UserController : Controller
    {
        private readonly IUserService service;
        private readonly ILogger<UserController> logger;

        private readonly IServiceResponseWrapper<string> serviceResponseWrapper;

        /// <summary>
        /// create the object of usercontroller.
        /// </summary>
        /// <param name="service">service dependenc injection.</param>
        public UserController(IUserService service, ILogger<UserController> logger
            , IServiceResponseWrapper<string> serviceResponseWrapper)
        {
            this.service = service;
            this.logger = logger;
            this.serviceResponseWrapper = serviceResponseWrapper;
        }
        
        /// <summary>
        /// user login
        /// </summary>
        /// <param name="userId">based on userId.</param>
        /// <param name="password">based on password</param>
        /// <returns>returns the status message.</returns>
        [Route("Login")]
        [HttpGet]
        public async Task<IServiceResponseWrapper<string>> Login(string userId, string password)
        {
            try
            {
                this.logger.LogTrace("Entered try block of User Login");
                if (!string.IsNullOrEmpty(userId) && !string.IsNullOrEmpty(password))
                {
                    serviceResponseWrapper.serviceResponse.serviceData.Add(this.service.Login(userId, password));
                }
            }

            catch (Exception ex)
            {
                this.logger.LogError("User Login ", ex);
            }
            return serviceResponseWrapper;
        }

        /// <summary>
        /// new user registration.
        /// </summary>
        /// <param name="userRegistration">userRegiastration.</param>
        /// <returns>returns the status message of user register.</returns>
        [Route("Register")]
        [HttpPost]
        public IActionResult Register([FromBody]Users userRegistration)
        {
            try
            {
                this.logger.LogTrace("Entered try block of User Register");
                if (userRegistration != null)
                {
                    var statusMessage = this.service.Register(userRegistration);
                    return Ok(statusMessage);
                }

            }
            catch (Exception ex)
            {
                this.logger.LogError("USer Registration ", ex);
            }

            return Ok(Constants.EnterUserDetails);


        }

        /// <summary>
        /// Updates the user password.
        /// </summary>
        /// <param name="userId">based on userId.</param>
        /// <param name="newPassword">updates the new password.</param>
        /// <returns>returns the status message whether the password is updated or not.</returns>
        [Route("UpdatePassword")]
        [HttpPut]
        public IActionResult UpdatePassword(string userId, string oldpassword,string newPassword)
        {
            try
            {
                this.logger.LogTrace("Entered try block of Password Update");
                if (!string.IsNullOrEmpty(userId) && !string.IsNullOrEmpty(newPassword))
                {
                    var result = this.service.UpdatePassword(userId, oldpassword,newPassword);
                    if(result>0)
                        return Ok(Constants.UpdateSuccess);
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError("Password Update", ex);
            }
            return Ok(Constants.UpdateFailed);
        }

        [Route("ForgotPasswordEmailId")]
        [HttpGet]
        public IActionResult PasswordUpdateEmailId(string emailid)
        {
            try
            {
                this.logger.LogTrace("Entered try block of Password Update EmailId ");
                if (!string.IsNullOrEmpty(emailid))
                {
                    var result = this.service.ForgotPasswordEmailId(emailid);
                    return Ok(result);
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError("Password Update EmailId", ex);
            }

            return Ok(Constants.ModifyPassFail);
        }

        [Route("ForgotPassword")]
        [HttpPut]
        public IActionResult PasswordUpdateEmailId(string userId,string newPassword)
        {
            try
            {
                this.logger.LogTrace("Entered try block of Password Update EmailId ");
                if (!string.IsNullOrEmpty(userId)&&!string.IsNullOrEmpty(newPassword))
                {
                    var result = this.service.ForgotPassword(userId,newPassword);
                    return Ok(result);
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError("Password Update EmailId ", ex);
            }
            return Ok(Constants.UpdateFailed);
        }
    }
}
