﻿namespace TweetApp.Models
{
    public interface IServiceResponseWrapper<T> where T : class
    {
        ServiceResponse<T> serviceResponse { get; set; }
    }
}