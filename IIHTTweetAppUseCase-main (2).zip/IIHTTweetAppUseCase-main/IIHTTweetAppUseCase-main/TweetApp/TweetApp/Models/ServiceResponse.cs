﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TweetApp.Models
{
    public class ServiceResponse<T> where T : class
    {
        public ServiceResponse()
        {
            this.serviceStatus = new ServiceStatus();
            this.serviceData = new List<T>();
        }
        public ServiceStatus serviceStatus { get; set; }
        public IList<T> serviceData { get; set; }
    }
}
