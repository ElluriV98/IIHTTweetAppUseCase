﻿namespace TweetApp.Models
{
    public class ServiceResponseWrapper<T> : IServiceResponseWrapper<T> where T : class
    {
        public ServiceResponseWrapper()
        {
            this.serviceResponse = new ServiceResponse<T>();
        }
        public ServiceResponse<T> serviceResponse { get; set; }
    }
}
