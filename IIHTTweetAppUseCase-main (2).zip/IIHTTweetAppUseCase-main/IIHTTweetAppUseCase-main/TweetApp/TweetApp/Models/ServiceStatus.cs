﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TweetApp.Models
{
    public class ServiceStatus
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
