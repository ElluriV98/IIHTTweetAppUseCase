﻿using System;
using System.Collections.Generic;

namespace TweetApp.Models
{
    public partial class Tweets
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string Tweets1 { get; set; }
    }
}
