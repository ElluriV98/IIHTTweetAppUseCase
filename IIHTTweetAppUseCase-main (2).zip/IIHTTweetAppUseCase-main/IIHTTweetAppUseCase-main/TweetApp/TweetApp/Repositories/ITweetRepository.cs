﻿using System;
using System.Collections.Generic;
using System.Text;
using TweetApp.Models;

namespace TweetApp.Repositories
{
    /// <summary>
    /// IRepository interface.
    /// </summary>
    public interface ITweetRepository
    { 

        bool AddTweet(Tweets tweet);

        List<Tweets> GetUserTweets(string userId);

        List<AllUsers> GetAllUsers();

        List<Tweets> GetUserandTweetList();

    }
}
