﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Models;

namespace TweetApp.Repositories
{
    public interface IUserRepository
    {
        Task<int> UserRegister(Users userRegister);

        Task<Users> Userlogin(string userId);

        Task<Users> UserExist(string emailId);

        Task<int> UpdatePassword(string userId, string oldPassword, string newPassword);

        Task<bool> ForgotPasswordEmail(string emailId);
        Task<int> ForgotPassword(string emailId, string newPassword);
    }
}
