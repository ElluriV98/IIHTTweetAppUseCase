﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using TweetApp.Models;

namespace TweetApp.Repositories
{
    /// <summary>
    /// Tweets repository.
    /// </summary>
    public class TweetRepository : ITweetRepository
    {
        
        /// <summary>
        /// adds the new tweet.
        /// </summary>
        /// <param name="tweet">tweet</param>
        public bool AddTweet(Tweets tweet)
        {
            using (var dbContext = new TweetAppUseCaseContext())
            {
                dbContext.Tweets.Add(tweet);
                var result =dbContext.SaveChanges();
                return result > 0;
            }

        }

        /// <summary>
        /// get the particular user tweets.
        /// </summary>
        /// <param name="userId">userId.</param>
        /// <returns>returns the list of tweets.</returns>
        public List<Tweets> GetUserTweets(string userId)
        {
            using (var dbContext = new TweetAppUseCaseContext())
            {
                var tweets = dbContext.Tweets.Where(x => x.UserId == userId).ToList();
                return tweets;
            }
        }

        /// <summary>
        /// Get all the user list.
        /// </summary>
        /// <returns>returns the all user list.</returns>
        public List<AllUsers> GetAllUsers()
        {
            using (var dbContext = new TweetAppUseCaseContext())
            {
                var users = dbContext.Users.Select(p => new AllUsers
                {
                    FirstName = p.Firstname,
                    LastName = p.Lastname
                }).ToList();
                return users;
            }

        }

        /// <summary>
        /// Get all users and their respective Tweets.
        /// </summary>
        /// <returns>Returns the list users names and tweets.</returns>
        public List<Tweets> GetUserandTweetList()
        {
            using(var dbContext = new TweetAppUseCaseContext())
            {
                var userTweets = dbContext.Tweets.Select(p => p).ToList();
                return userTweets;

            }
        }
        /// <summary>
        /// updates the password.
        /// </summary>
        /// <param name="userId">Userid.</param>
        /// <param name="newPassword">Newpassword.</param>
        /// <returns></returns>

    }
}
