﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Models;

namespace TweetApp.Repositories
{
    public class UserRepository: IUserRepository
    {
        /// <summary>
        /// Checks the user is exists or not.
        /// </summary>
        /// <param name="emailId"> based on userID.</param>
        /// <returns>returns the user details if found.</returns>
        public async Task<Users> UserExist(string emailId)
        {
            using (var dbContext = new TweetAppUseCaseContext())
            {
                var user = await dbContext.Users.Where(s => s.EmailId == emailId).FirstOrDefaultAsync();
                return user;
            }
        }

        /// <summary>
        /// user login.
        /// </summary>
        /// <param name="userId">based on user id fetches the encoded password</param>
        /// <returns></returns>
        public async Task<Users> Userlogin(string userId)
        {
            using (var dbContext = new TweetAppUseCaseContext())
            {
                var user = await dbContext.Users.Where(s => s.EmailId == userId).FirstOrDefaultAsync();
                return user;

            }
        }

        /// <summary>
        /// registered the new user
        /// </summary>
        /// <param name="userRegister">user details.</param>
        public async Task<int> UserRegister(Users userRegister)
        {
            using (var dbContext = new TweetAppUseCaseContext())
            {
                dbContext.Users.Add(userRegister);
                var result =await dbContext.SaveChangesAsync();
                return result;

            }
        }

        public async Task<int> UpdatePassword(string userId, string oldPassword, string newPassword)
        {
            using (var dbContext = new TweetAppUseCaseContext())
            {
                Users users = new Users();

                var userDetails = await dbContext.Users.Where(x => x.EmailId == userId && x.Password == oldPassword).FirstOrDefaultAsync();
                if (userDetails != null)
                {
                    userDetails.Password = newPassword;
                    dbContext.Users.Update(userDetails);
                    var result = dbContext.SaveChanges();
                    return result;
                }

                return 0;

            }
        }

        public async Task<bool> ForgotPasswordEmail(string emailId)
        {
            using (var dbContext = new TweetAppUseCaseContext())
            {
                var userDetails = await dbContext.Users.Where(s => s.EmailId == emailId).FirstOrDefaultAsync();
                if (userDetails != null)
                {
                    return true;
                }
                return false;
            }
        }

        public async Task<int> ForgotPassword(string emailId, string newPassword)
        {
            using (var dbContext = new TweetAppUseCaseContext())
            {
                var userDetails =await dbContext.Users.Where(s => s.EmailId == emailId).FirstOrDefaultAsync();
                if (userDetails != null)
                {
                    userDetails.Password = newPassword;
                    dbContext.Update(userDetails);
                    var result = dbContext.SaveChanges();
                    return result;
                }
                return 0;
            }
        }

    }

}
