﻿using System;
using System.Collections.Generic;
using System.Text;
using TweetApp.Models;

namespace TweetApp.Services
{
    /// <summary>
    /// ITweetService interface.
    /// </summary>
    public interface ITweetService
    {
       
        string AddNewTweet(Tweets tweet);
        List<Tweets> GetUserTweets(string userId);
        List<AllUsers> AllUserList();
        List<Tweets> GetUserandTweetList();
 
    }
}
