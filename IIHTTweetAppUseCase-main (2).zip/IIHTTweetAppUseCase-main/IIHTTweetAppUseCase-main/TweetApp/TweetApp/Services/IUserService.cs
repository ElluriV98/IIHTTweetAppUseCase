﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Models;

namespace TweetApp.Services
{
    public interface IUserService
    {
        Task<string> Register(Users userRegister);
        Task<string> Login(string userID, string password);
        Task<int> UpdatePassword(string userId, string oldPassword, string newPassword);
        Task<string> ForgotPasswordEmailId(string emailId);
        Task<string> ForgotPassword(string emailId, string newPassword);
    }
}
