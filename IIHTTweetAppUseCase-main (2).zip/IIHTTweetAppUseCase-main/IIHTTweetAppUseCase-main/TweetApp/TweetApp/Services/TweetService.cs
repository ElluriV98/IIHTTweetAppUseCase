﻿using System;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using TweetApp.Models;
using TweetApp.Repositories;

namespace TweetApp.Services
{
    /// <summary>
    /// TweetService.
    /// </summary>
    public class TweetService : ITweetService
    {
        private readonly ITweetRepository queries;

        /// <summary>
        /// create the instance of tweet service.
        /// </summary>
        /// <param name="queries"></param>
        public TweetService( ITweetRepository queries)
        {
            this.queries = queries;
        }

       
        /// <summary>
        /// Gets the particular user tweets.
        /// </summary>
        /// <param name="userId">Based on userId.</param>
        /// <returns>returns the list of tweets.</returns>
        public List<Tweets> GetUserTweets(string userId)
        {
            var tweets = this.queries.GetUserTweets(userId);
            return tweets;
        }

        public string AddNewTweet(Tweets tweet)
        {
            if(tweet != null)
            {
                var result = this.queries.AddTweet(tweet);
                if (result == true)
                {
                    return Constants.InsertSuccess;
                }
            }
            return Constants.InsertFailed;
        }

        /// <summary>
        /// get all the user list.
        /// </summary>
        /// <returns>returns the list of users.</returns>
        public List<AllUsers> AllUserList()
        {
            var userList =this.queries.GetAllUsers();
            return userList;
        }

        public List<Tweets> GetUserandTweetList()
        {
            var result = this.queries.GetUserandTweetList();
            return result;
        }

       
    }
}
