﻿using System;
using System.Threading.Tasks;
using TweetApp.Models;
using TweetApp.Repositories;

namespace TweetApp.Services
{
    public class UserService :IUserService
    {
        private readonly IUserRepository queries;

        /// <summary>
        /// create the instance of tweet service.
        /// </summary>
        /// <param name="queries"></param>
        public UserService(IUserRepository queries)
        {
            this.queries = queries;
        }


        /// <summary>
        ///  check that wheather that user is existed or not. if found returns alread existed message, else save the user details.
        /// </summary>
        /// <param name="userRegister">user details.</param>
        /// <returns>returns the status message.</returns>
        public async Task<string> Register(Users userRegister)
        {
            if (userRegister != null)
            {
                var user = this.queries.UserExist(userRegister.EmailId);
                if (user == null)
                {
                    userRegister.Password = this.EncryptPassCode(userRegister.Password);
                    var result =await queries.UserRegister(userRegister);
                    return result > 0 ? Constants.RegisterSuccess : Constants.RegisterFailed;
                }

            }
            return "";
        }

        /// <summary>
        /// User Login
        /// </summary>
        /// <param name="userID">based on userId.</param>
        /// <param name="password">based on password.</param>
        /// <returns>returns the status message.</returns>
        public async Task<string> Login(string userID, string password)
        {

            var user =await this.queries.Userlogin(userID);
            var decodedPassword = DecryptPassCode(user.Password);
            if (user != null && password == decodedPassword)
                return string.Concat(userID,Constants.LoginSuccess);
            return string.Concat(userID,Constants.LoginFailure);
        }

        /// <summary>
        /// Encodes the password
        /// </summary>
        /// <param name="password">passord.</param>
        /// <returns>Returns the encoded password.</returns>
        private string EncryptPassCode(string password)
        {
            byte[] encryptData = new byte[password.Length];
            encryptData = System.Text.Encoding.UTF8.GetBytes(password);
            string encodedData = Convert.ToBase64String(encryptData);
            return encodedData;
        }

        /// <summary>
        /// Decodes the password.
        /// </summary>
        /// <param name="password">password.</param>
        /// <returns>Returns the Decoded password.</returns>
        private string DecryptPassCode(string password)
        {
            System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
            System.Text.Decoder utf8Decode = encoder.GetDecoder();
            byte[] decode = Convert.FromBase64String(password);
            int charCount = utf8Decode.GetCharCount(decode, 0, decode.Length);
            char[] decoded_char = new char[charCount];
            utf8Decode.GetChars(decode, 0, decode.Length, decoded_char, 0);
            string result = new String(decoded_char);
            return result;
        }

        /// <summary>
        /// updates the new password.
        /// </summary>
        /// <param name="userId">based on userId.</param>
        /// <param name="newPassword">will add the new password.</param>
        /// <returns>returns the boolean value.</returns>
        public async Task<int> UpdatePassword(string userId, string oldpassword, string newPassword)
        {
            newPassword = this.EncryptPassCode(newPassword);
            oldpassword = this.EncryptPassCode(oldpassword);
            var result =await this.queries.UpdatePassword(userId, oldpassword, newPassword);
            return result;
        }


        public async Task<string> ForgotPasswordEmailId(string emailId)
        {
            var res =await this.queries.ForgotPasswordEmail(emailId);
            return res ? Constants.ModifyPass : Constants.ModifyPassFail;
        }

        public async Task<string> ForgotPassword(string emailId, string newPassword)
        {
            newPassword = this.EncryptPassCode(newPassword);
            var res = await this.queries.ForgotPassword(emailId, newPassword);
            string result =res >0 ? Constants.UpdateSuccess: Constants.UpdateFailed;
            return result;
        }
    }
}
