using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using TweetApp.Models;
using TweetApp.Repositories;
using TweetApp.Services;

namespace TweetApp
{
    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
           services.AddScoped<ITweetRepository, TweetRepository>();
           services.AddScoped<ITweetService, TweetService>();
           services.AddScoped<IUserService, UserService>();
           services.AddScoped<IUserRepository, UserRepository>();
           services.AddScoped<IServiceResponseWrapper<string>, ServiceResponseWrapper<string>>();
           
           services.AddSwaggerGen(c => { c.SwaggerDoc("Tweet", 
               new OpenApiInfo { Title = "TweetApp", Version = "Tweet" }); });
            services.AddControllers();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseSwagger();
            app.UseSwaggerUI(c => { c.SwaggerEndpoint("/swagger/Tweet/swagger.json", "TweetApp"); });
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
