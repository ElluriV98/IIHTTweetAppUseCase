﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TweetApp.Models
{
    public partial class Tweet
    {
        public int Id { get; set; }
        public int? UserId { get; set; }
        public string Tweeets { get; set; }

        public virtual UserDetail User { get; set; }
    }
}
