﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Models;

namespace TweetAPP.Repositories
{
    public interface ITweetRepository
    {
        Task<int> Register(UserDetail users);

        Task<bool> Login(string emailId, string password);

        Task<IList<Tweet>> GetAllTweets();

        Task<IList<Tweet>> GetTweetsByUser(int userID);

        Task<IList<UserDetail>> GetAllUsers();

        Task<int> PostTweet(Tweet tweet);

        Task<bool> UpdatePassword(string emailId, string oldpassword, string newPassword);

        Task<bool> ForgotPassword(string emailId, string password);

        Task<UserDetail> ValidateEmailId(string emailId);
    }
}
