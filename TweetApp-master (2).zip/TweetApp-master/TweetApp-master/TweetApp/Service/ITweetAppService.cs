﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Models;

namespace TweetAPP.Service
{
    public interface ITweetAppService
    {
        Task<string> UserRegister(UserDetail users);

        Task<string> UserLogin(string emailId, string password);

        Task<IList<Tweet>> GetAllTweets();

        Task<IList<Tweet>> GetTweetsByUser(int userID);

        Task<IList<UserDetail>> GetAllUsers();

        Task<string> PostTweet(Tweet tweet);

        Task<string> UpdatePassword(string emailId, string oldpassword, string newPassword);
        Task<string> ForgotPassword(string emailId, string password);

    }
}
